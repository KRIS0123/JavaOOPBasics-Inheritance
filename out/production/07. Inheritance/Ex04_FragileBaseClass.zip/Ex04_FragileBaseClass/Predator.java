package Ex04_FragileBaseClass;

public class Predator extends Animal {
    private Integer health;
    public void feed(Food food){

    }
}
