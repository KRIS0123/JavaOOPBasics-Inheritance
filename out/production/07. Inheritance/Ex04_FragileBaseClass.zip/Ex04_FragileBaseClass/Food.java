package Ex04_FragileBaseClass;

public class Food {
}
