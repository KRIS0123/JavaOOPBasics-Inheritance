package Ex04_FragileBaseClass;

import java.util.ArrayList;

public class Animal {
    protected ArrayList<Food> foodEaten;
    public final void eat(Food food){

    }
    public final void eatAll(Food[] food){

    }

}
