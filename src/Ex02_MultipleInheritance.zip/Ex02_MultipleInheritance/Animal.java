package Ex02_MultipleInheritance;

public class Animal {
    public void eat(){
        System.out.println("eating...");
    }
}
